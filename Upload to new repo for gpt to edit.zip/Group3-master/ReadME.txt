This is the runnable (basic) Demo for the Front end thorugh Vite.

This does require NODE js to be installed in order to be run.
There is an executable file called RunExecutable.py that you can simply run to 
start the vite server, you can use h+enter to see the commands or o+enter right away
to see the website.
The email and password as of right now is: 
admin@gmail.com
PS: admin

As of right now the Executable file needs the specific file path to "dashboard-react"
in the "Frontend" folder on your local machine specicified in the "file_path=" variable.

Otherwise you would need to open a terminal, navigate to "Frontend\dashboard-react" file,
and run these commands inside that folder:
"npm install" (installs npm for react/vite)
"npm run dev"